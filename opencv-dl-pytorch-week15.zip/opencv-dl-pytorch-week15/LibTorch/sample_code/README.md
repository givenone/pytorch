# libtorch-sample-code

This is a basic example showing how to define a Torch Tensor and display it.
